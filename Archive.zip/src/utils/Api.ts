import { environment } from '../environments/environment';

const {baseUrl} = environment; 

const endPoints = {
    employess: `${baseUrl}/emplyess.json`
}

export default endPoints;