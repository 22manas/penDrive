export const environment = {
  production: false,
  baseUrl: "../assets/data"
};
