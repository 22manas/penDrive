export const environment = {
  production: true,
  baseUrl: "https://myrealserver.com"
};
