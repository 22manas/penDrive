import { Component, OnInit } from '@angular/core';
import Endpoints from '../../utils/Api';

import { HttpClient} from '@angular/common/http'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  tlSelectedMonth:any;
  totalLessonsMonthList:any=["January","February","March","April"];
  nlSelectedMonth:any;
  newLessonsMonthList:any=["January","February","March","April"];
  theMonthOfList:any=["January","February","March","April"];
  theMonthOfSelected:any;
  
  constructor(private $http: HttpClient) { }

  ngOnInit(): void {
    this.tlSelectedMonth=this.totalLessonsMonthList[0];
    this.nlSelectedMonth=this.newLessonsMonthList[0];
    this.theMonthOfSelected=this.theMonthOfDropdownSel[0];
    this.$http.get(Endpoints.employess).subscribe(
      data => {
        console.log({das: data});
      },
      err => {
        console.log({err});
      }
    );
  }
  tlDropdownSel($event){
    alert($event);
  }
  nlDropdownSel($event){
    alert($event);
  }
  theMonthOfDropdownSel($event){
    alert($event);
  }

}
