import { NgControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import EndPoints from '../utils/Api';
import { HttpClient} from '@angular/common/http'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'rehab';
  employees: any = [];
  constructor(private $http: HttpClient){
    console.log('EndPoints', EndPoints);
  }

  ngOnInit() {
    this.$http.get(EndPoints.employess).subscribe(
      data => {
        console.log({data});
        this.employees = data
      },
      err => {
        console.log({err});
      }
    );
  }
}
